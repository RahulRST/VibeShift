## VibeShift

VibeShift is a web application which can be used to play music.

## About

VibeShift is a
- Web application
- Music player
- Developed using Django
- Search for songs

## Tech Stack

- Django

## Installation

1. Clone the repository
2. Install the requirements
3. Run the server

## Usage

1. Open the browser
2. Go to the URL: http://localhost:8000
3. Play the music

